const path = require('path');

module.exports = {
    entry: './src/wafu.js',
    output: {
        filename: 'wafu.js',
        path: path.resolve(__dirname, 'dist'),
        library: 'wafu',
        libraryTarget: 'umd'
    },
    module: {
        rules: [
            {
                test: /\.js$/,
                exclude: /node_modules/,
                use: {
                    loader: 'babel-loader',
                    options: {
                        presets: [
                            "@babel/preset-env"
                        ]
                    }
                }
            }
        ]
    }
};